# Job-Scraping Website

This is a MERN stack job-scraping website with a responsive UI and pre-configured MongoDB connection.

## Requirements

- Node.js
- MongoDB Atlas or Local MongoDB Server

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone <repository-url>
   ```

2. Navigate to the `server` folder and install dependencies:
   ```bash
   cd server
   npm install
   ```

3. Create a `.env` file in the `server` folder and add your MongoDB URI:
   ```
   MONGO_URI=your_mongo_uri
   ```

4. Start the backend server:
   ```bash
   npm start
   ```

5. Navigate to the `client` folder and install dependencies:
   ```bash
   cd ../client
   npm install
   ```

6. Start the React development server:
   ```bash
   npm start
   ```

7. Open `http://localhost:3000` in your browser to view the application.